package com.williansmartins.desafio3;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Desafio 3!" );
    }
}
